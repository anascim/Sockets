﻿using System;
using System.Net;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Generic;

class MainClass
{
    public static void Menu()
    {
        Console.WriteLine("Press 1 to start a Server");
        Console.WriteLine("Press 2 to start a Client");
        Console.WriteLine("Press anything else to exit...");
        char input = Console.ReadKey().KeyChar;
        Console.WriteLine(input);
        if (input == '1')
        {
            Console.WriteLine("Inform a host/IP...");
            string ip = Console.ReadLine();

            Console.WriteLine("Inform a port...");
            string port = Console.ReadLine();
            int nport = 0;

            try
            {
                nport = int.Parse(port);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Exiting the application...");
                Environment.Exit(0);
            }

            Console.WriteLine("Inform the client capacity...");
            string capacity = Console.ReadLine();
            uint ncapacity = 0;

            try
            {
                ncapacity = uint.Parse(capacity);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Exiting the application...");
                Environment.Exit(0);
            }

            _ = new Server(ip, nport, uint.Parse(capacity));
        }
        else if (input == '2')
        {
            Console.WriteLine("Inform a host/IP...");
            string ip = Console.ReadLine();

            Console.WriteLine("Inform a port...");
            string port = Console.ReadLine();
            int nport = 0;

            try
            {
                nport = int.Parse(port);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Console.WriteLine("Exiting the application...");
                Environment.Exit(0);
            }

            Console.WriteLine("Inform yout name...");
            string name = Console.ReadLine();

            _ = new Client(ip, nport, name);
        }
        else
        {
            Console.WriteLine("Exiting Application...");
            Environment.Exit(0);
        }
    }

    public static void Main(string[] args)
    {
        Menu();
    }
}

class Server
{
    string ip;
    int port;
    uint clients;

    public Server(string ip, int port, uint clients)
    {
        this.ip = ip;
        this.port = port;
        this.clients = clients;
        StartServer(ip, port, clients);
    }

    public void StartServer(string server, int port, uint clients)
    {
        IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
        IPAddress ipAdress = ipHostInfo.AddressList[0];
        IPEndPoint ipEndPoint = new IPEndPoint(ipAdress, port);

        List<Connection> connections = new List<Connection>((int)clients);

        // cria o socket mas ainda não o atribui a um ip/port
        Socket socket = new Socket(ipAdress.AddressFamily,
            SocketType.Stream,
            ProtocolType.Tcp);

        try
        {
            socket.Bind(ipEndPoint); // liga o socket a um ip/port, representado pela classe IPEndPoint
            socket.Listen((int)clients);

            Socket[] clientSockets = new Socket[clients];

            Console.WriteLine("> WAITING FOR A CONNECTION...");

            Thread connectionsThread = new Thread(() => WaitForConnections(clientSockets, socket));
            connectionsThread.Start();

            while (true)
            {
                string input = Console.ReadLine();

                if (input == "/encerrar")
                {
                    foreach (Socket client in clientSockets)
                    {
                        if (client == null) continue;
                        byte[] msg = Encoding.ASCII.GetBytes("/encerrar<EOF>");
                        client.Send(msg);
                        client.Shutdown(SocketShutdown.Both);
                        client.Close();
                    }
                    break;
                }
            }
            connectionsThread.Abort();
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }

        socket.Shutdown(SocketShutdown.Both);
        socket.Close();

        Console.WriteLine("\nPress ENTER to continue...");
        Console.Read();
    }

    void WaitForConnections(Socket[] clientSockets, Socket serverSocket)
    {
        for (int i = 0; i < clientSockets.Length; i++)
        {
            if (clientSockets[i] != null) continue;
            clientSockets[i] = serverSocket.Accept(); // para o código até receber uma conexão. É uma referência para o cliente
            Connection connection = new Connection(clientSockets[i]);
        }
    }
}

class Client
{
    string server;
    int port;
    string name;

    public Client(string server, int port, string name)
    {
        this.server = server;
        this.port = port;
        this.name = name;
        StartClient(server, port, name);
    }

    void StartClient(string server, int port, string name)
    {
        IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
        IPAddress ipAdress = ipHostInfo.AddressList[0];
        IPEndPoint ipEndPoint = new IPEndPoint(ipAdress, port);

        Socket socket = new Socket(ipAdress.AddressFamily,
            SocketType.Stream,
            ProtocolType.Tcp);

        try
        {
            socket.Connect(ipEndPoint);
            Console.WriteLine("> CONNECTED TO {0}", socket.RemoteEndPoint);

            Thread thread = new Thread(() => ReceiveMessages(socket));
            thread.Start();

            while (true)
            {
                string strmsg = null;
                // send messages
                strmsg = Console.ReadLine(); // string message
                byte[] message = Encoding.ASCII.GetBytes(strmsg + "<EOF>");
                socket.Send(message);

                if (strmsg == "/sair")
                {
                    if (socket.Connected)
                    {
                        socket.Shutdown(SocketShutdown.Both);
                        socket.Close();
                    }
                    break;
                }
            }
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }

        Console.WriteLine("\nPress ENTER to continue...");
        Console.Read();
    }

    void ReceiveMessages(Socket socket)
    {
        byte[] buffer = new byte[1024];

        // receive messages
        string data = "";
        while (true)
        {
            int bytesReceived = socket.Receive(buffer);
            data += Encoding.ASCII.GetString(buffer, 0, bytesReceived);

            if (data.IndexOf("<EOF>") > -1) //EOF: End Of File. Poderia colocar qualquer coisa como final de msg
            {
                if (data == "/encerrar<EOF>")
                {
                    Console.WriteLine("> ENCERRANDO SERVIDOR...");
                    if (socket.Connected)
                    {
                        socket.Shutdown(SocketShutdown.Both);
                        socket.Close();
                    }
                }
                break;
            }

            Console.WriteLine("[SERVER] {0}", data.Remove(data.Length - 5));
        }

    }
}

class Connection
{
    Socket m_ClientSocket;

    public Connection(Socket clientSocket)
    {
        m_ClientSocket = clientSocket;
        Console.WriteLine("> {0} CONNECTED.", clientSocket.RemoteEndPoint); // EndPoint é o endereço do cliente, ou seja, de quem conectou conosco
        StartThread();
    }

    public void StartThread()
    {
        Thread thread = new Thread(StartClientConnection);
        thread.Start(m_ClientSocket);
    }

    void StartClientConnection(object clientSock)
    {
        Socket handler = clientSock as Socket;

        byte[] buffer = new byte[1024];

        while (true) // enquanto conectado com o cliente
        {
            string data = null;
            // Recebe as mensagens até encontrar <EOF>
            while (true)
            {
                int bytesReceived = handler.Receive(buffer);
                data += Encoding.ASCII.GetString(buffer, 0, bytesReceived);

                if (data.IndexOf("<EOF>") > -1) //EOF: End Of File
                {
                    data = data.Remove(data.Length - 5);
                    break;
                }
            }

            if (data == "/sair")
            {
                if (handler.Connected)
                {
                    handler.Shutdown(SocketShutdown.Both);
                    handler.Close();
                }
                Console.WriteLine("> CLIENT DISCONNECTED.");
                m_ClientSocket = null;
                break;
            }

            Console.WriteLine("[CLIENT] {0}", data);

            // envia mensagem ao cliente
            byte[] message = Encoding.ASCII.GetBytes("Size: " + data.Length + " characters; " + data.ToUpper() + "<EOF>");
            handler.Send(message);
        }
    }
}
